package com.vigil.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import org.json.JSONArray

class BlockerService : AccessibilityService() {
    private var lastToast = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val p = getSharedPreferences("vigil", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now >= p.getLong("end", 0L)) return
        val blocked = try {
            val a = JSONArray(p.getString("pk", "[]"))
            (0 until a.length()).map { a.getString(it) }.toSet()
        } catch (x: Exception) { emptySet() }
        if (pkg in blocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            if (now - lastToast > 1500) {
                lastToast = now
                Toast.makeText(this, "Blocked by Vigil. Stay focused.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onInterrupt() {}
}
