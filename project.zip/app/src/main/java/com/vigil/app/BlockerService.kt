package com.vigil.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import org.json.JSONArray

class BlockerService : AccessibilityService() {
    private var lastToast = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val p = getSharedPreferences("vigil", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now >= p.getLong("end", 0L)) return
        val blocked = try {
            val a = JSONArray(p.getString("pk", "[]"))
            (0 until a.length()).map { a.getString(it) }.toSet()
        } catch (x: Exception) { emptySet() }
        if (pkg in blocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            if (now - lastToast > 1500) {
                lastToast = now
                Handler(Looper.getMainLooper()).postDelayed({
                    startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                }, 200)
            }
        }
    }

    override fun onInterrupt() {}
}
