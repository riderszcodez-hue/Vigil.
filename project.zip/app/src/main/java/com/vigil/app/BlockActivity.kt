package com.vigil.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF080812.toInt()
        window.navigationBarColor = 0xFF080812.toInt()
        val p = getSharedPreferences("vigil", MODE_PRIVATE)
        val msg = p.getString("msg", null)?.ifBlank { null } ?: "Get back to work."
        val mins = ((p.getLong("end", 0L) - System.currentTimeMillis()) / 60000L).coerceAtLeast(0L) + 1
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF080812.toInt())
            setPadding(64, 64, 64, 64)
        }
        val t = TextView(this).apply {
            text = msg; textSize = 34f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        }
        val s = TextView(this).apply {
            text = "$mins min left on your lock"; textSize = 16f
            setTextColor(0xFFA7A7B8.toInt()); gravity = Gravity.CENTER; setPadding(0, 24, 0, 48)
        }
        val btn = Button(this).apply { text = "Back to focus"; setOnClickListener { goHome() } }
        root.addView(t); root.addView(s); root.addView(btn)
        setContentView(root)
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }
}
