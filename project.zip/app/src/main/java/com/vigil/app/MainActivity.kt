package com.vigil.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF080812.toInt()
        window.navigationBarColor = 0xFF080812.toInt()
        web = WebView(this)
        web.setBackgroundColor(0xFF080812.toInt())
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { startActivityForResult(p.createIntent(), 1); true } catch (e: Exception) { fileCb = null; false }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d))
            fileCb = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = packageManager.queryIntentActivities(i, 0)
                .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
                .filter { it.first != packageName && !it.first.startsWith("com.android.settings") }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("p", it.first).put("n", it.second)) }
            return arr.toString()
        }

        @JavascriptInterface
        fun isEnabled(): Boolean {
            val cn = ComponentName(this@MainActivity, BlockerService::class.java)
            val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            return s.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
        }

        @JavascriptInterface
        fun openSettings() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        @JavascriptInterface
        fun startLock(pkgs: String, end: Long) {
            getSharedPreferences("vigil", MODE_PRIVATE).edit().putString("pk", pkgs).putLong("end", end).apply()
        }

        @JavascriptInterface
        fun setMessage(m: String) {
            getSharedPreferences("vigil", MODE_PRIVATE).edit().putString("msg", m.ifBlank { "Get back to work." }).apply()
        }

        @JavascriptInterface
        fun stopLock() {
            getSharedPreferences("vigil", MODE_PRIVATE).edit().putLong("end", 0L).apply()
        }
    }
}
